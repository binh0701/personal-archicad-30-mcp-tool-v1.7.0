#!/usr/bin/env python3
"""archicad-30-BinhNguyen - MCP server for Archicad 30 (AI Productivity Challenge, Parts 1 and 2).

Part 1: finds doors with a missing fire rating, links each door to its host
wall and fills the rating in one batch after a preview. The same tools work on
windows with elementType='Window' (v1.7.0).
Part 2: measures every wall, totals length and area per layer / wall type and
prices them with the user's rates. Part 2 is read-only.
Housekeeping: finds Element IDs used by more than one element and renames
elements (changes their Element ID) after a preview.

No third-party packages and no extra Archicad add-on are needed: it talks to
the official Archicad JSON API (ports 19723-19743 on this machine) using only
the Python standard library, and speaks MCP over stdio (newline-delimited
JSON-RPC).

Ground rule of the challenge: it only ever writes the value of an existing
property - the fire rating of doors and windows (Part 1) or of walls (preview_wall_fire_rating /
apply_wall_fire_rating, v1.6.0) or, with the rename tools, the Element ID.
All writes go through a preview that the user has to confirm. It never creates,
moves or deletes elements; the wall measuring and pricing tools change nothing.
"""
import json
import os
import re
import socket
import sys
import urllib.error
import urllib.request
import uuid
from concurrent.futures import ThreadPoolExecutor

SERVER_NAME = "archicad-30-BinhNguyen"
SERVER_VERSION = "1.7.0"
HOST = "127.0.0.1"
PORTS = range(19723, 19744)  # Archicad takes the first free port in this range per instance
CHUNK = 2000                 # elements per API call, keeps requests small on big models
DEFAULT_LIMIT = 20           # rows returned per list; counts are always complete

# Shortcuts for the two fire rating properties of the Archicad 30 INT template.
# Any other property can be given as "GROUP/Name" (user-defined) or by its
# built-in non-localized name.
FIRE_PROPERTIES = {
    "door": {"type": "BuiltIn", "nonLocalizedName": "WindowDoor_FireRating"},
    "general": {"type": "UserDefined", "localizedName": ["GENERAL RATINGS", "Fire Resistance Rating"]},
}
WALL_FIRE_PROPERTY = FIRE_PROPERTIES["general"]
BBOX_TOLERANCE = 0.01   # metres; overlaps thinner than this are ignored
STOREY_TOLERANCE = 0.005

_state = {"port": None}
_previews = {}  # preview_id -> prepared batch, kept until applied


class ArchicadError(Exception):
    pass


# ---------------------------------------------------------------- finding Archicad

def raw_call(port, command, parameters=None, timeout=120):
    body = {"command": command}
    if parameters is not None:
        body["parameters"] = parameters
    request = urllib.request.Request("http://%s:%d" % (HOST, port), json.dumps(body).encode("utf-8"))
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return json.load(response)


def probe(port):
    """Returns the product info of the Archicad listening on this port, or None.

    An Archicad that is there but cannot answer (a dialog is open, or it is
    busy) still counts as running: it comes back as {"busy": reason}.
    """
    try:
        socket.create_connection((HOST, port), timeout=0.5).close()
    except OSError:
        return None
    try:
        reply = raw_call(port, "API.GetProductInfo", timeout=10)
    except socket.timeout:
        return {"busy": "Archicad does not answer; it may be busy"}
    except (OSError, ValueError):
        return None
    if not isinstance(reply, dict) or "succeeded" not in reply:
        return None
    if reply["succeeded"]:
        return reply.get("result")
    return {"busy": reply.get("error", {}).get("message", "Archicad refused the request")}


def find_instances():
    with ThreadPoolExecutor(max_workers=len(PORTS)) as pool:
        infos = list(pool.map(probe, PORTS))
    return [(port, info) for port, info in zip(PORTS, infos) if info]


def select_port(requested=None):
    """Decides which Archicad instance the tools talk to and remembers it."""
    if requested is not None:
        requested = int(requested)
        if probe(requested) is None:
            raise ArchicadError("No Archicad answers on port %d." % requested)
        _state["port"] = requested
    if _state["port"] is not None:
        return _state["port"]
    env_port = os.environ.get("ARCHICAD_PORT")
    if env_port:
        return select_port(env_port)
    instances = find_instances()
    if not instances:
        raise ArchicadError("No running Archicad found on ports %d-%d. Open Archicad with a project first."
                            % (PORTS[0], PORTS[-1]))
    if len(instances) > 1:
        raise ArchicadError(
            "Several Archicad instances are running, on ports %s. Call archicad_status to see them, then pass "
            "port=<number> to the tool (it is remembered), or close the instance you do not need."
            % ", ".join(str(port) for port, _ in instances))
    _state["port"] = instances[0][0]
    return _state["port"]


def ac(command, parameters=None, port=None):
    port = port or select_port()
    try:
        reply = raw_call(port, command, parameters)
    except socket.timeout:
        raise ArchicadError("Archicad on port %d did not answer %s in time; it may be busy." % (port, command))
    except (urllib.error.URLError, OSError) as error:
        if _state["port"] == port:
            _state["port"] = None  # look for Archicad again on the next call
        raise ArchicadError("Lost the connection to Archicad on port %d. Is it still open? (%s)" % (port, error))
    if not reply.get("succeeded"):
        message = reply.get("error", {}).get("message", reply)
        if "modal dialog" in str(message):
            raise ArchicadError("Archicad cannot answer while a dialog is open in it. Close the dialog and try "
                                "again. (%s)" % message)
        raise ArchicadError("%s failed: %s" % (command, message))
    return reply.get("result", {})


# ---------------------------------------------------------------- properties

def builtin(name):
    return {"type": "BuiltIn", "nonLocalizedName": name}


def chunks(items):
    for start in range(0, len(items), CHUNK):
        yield items[start:start + CHUNK]


def read_values(elements, names, port=None):
    """One list of raw property values per element, aligned with names.

    A value is None when the project has no such property or Archicad returned
    an error for that element, so a missing property never breaks a tool.
    """
    if not elements:
        return []
    ids = ac("API.GetPropertyIds", {"properties": names}, port)["properties"]
    known = [(index, pid) for index, pid in enumerate(ids) if "propertyId" in pid]
    result = [[None] * len(names) for _ in elements]
    if not known:
        return result
    row_index = 0
    for part in chunks(elements):
        rows = ac("API.GetPropertyValuesOfElements",
                  {"elements": part, "properties": [pid for _, pid in known]}, port)["propertyValuesForElements"]
        for row in rows:
            for (index, _), item in zip(known, row.get("propertyValues", [])):
                result[row_index][index] = item.get("propertyValue")
            row_index += 1
    return result


def plain(value):
    """Turns a raw property value into a plain Python value; None when it has no usable value."""
    if not value or value.get("status") != "normal":
        return None
    inner = value.get("value")
    if isinstance(inner, dict):  # enum
        return inner.get("displayValue") or inner.get("nonLocalizedValue")
    return inner


def is_missing(text):
    return text is None or str(text).strip() == "" or str(text).strip().lower() == "undefined"


def fire_property(which):
    which = (which or "door").strip()
    if which in FIRE_PROPERTIES:
        return FIRE_PROPERTIES[which]
    if "/" in which:
        group, name = which.split("/", 1)
        return {"type": "UserDefined", "localizedName": [group.strip(), name.strip()]}
    return builtin(which)


def property_label(name):
    return name.get("nonLocalizedName") or "/".join(name.get("localizedName", []))


def fire_property_id(which, port=None):
    """Id of the chosen fire rating property; a helpful error when this project does not have it."""
    name = fire_property(which)
    pid = ac("API.GetPropertyIds", {"properties": [name]}, port)["properties"][0]
    if "propertyId" in pid:
        return name, pid
    candidates = []
    for prop in ac("API.GetAllPropertyNames", None, port).get("properties", []):
        label = property_label(prop)
        if "fire" in label.lower() and not label.startswith(("Skylight_", "Zone_")):
            candidates.append(label)
    raise ArchicadError(
        "This project has no property '%s'. Fire-related properties that do exist: %s. "
        "Pass one of them as the 'property' argument." % (property_label(name), candidates or "none"))


# ---------------------------------------------------------------- storeys

def storey_table(port=None):
    """[(level, name)] of the project's storeys, or [] when Archicad does not report them."""
    try:
        tree = ac("API.GetNavigatorItemTree", {"navigatorTreeId": {"type": "ProjectMap"}}, port)
        ids = []

        def walk(item):
            if item.get("type") == "StoryItem":
                ids.append({"navigatorItemId": item["navigatorItemId"]})
            for child in item.get("children", []):
                walk(child.get("navigatorItem", {}))

        walk(tree.get("navigatorTree", {}).get("rootItem", {}))
        if not ids:
            return []
        items = ac("API.GetStoryNavigatorItems", {"navigatorItemIds": ids}, port)["navigatorItems"]
    except (ArchicadError, KeyError, TypeError):
        return []
    table = []
    for item in items:
        story = item.get("storyNavigatorItem")
        if story and story.get("floorLevel") is not None:
            name = ("%s %s" % (story.get("prefix", ""), story.get("name", ""))).strip()
            table.append((story["floorLevel"], name or "Story %s" % story.get("floorNumber")))
    return table


def storey_label(elevation, table):
    if elevation is None:
        return "no storey"
    for level, name in table:
        if abs(level - elevation) <= STOREY_TOLERANCE:
            return name
    return "%+.2f m" % elevation


# ---------------------------------------------------------------- model reading

OPENING_TYPES = ("Door", "Window")  # both sit in a wall and share the Window/Door > Fire Rating property


def opening_type(args):
    """'Door' (default) or 'Window': the element type the Part 1 tools work on."""
    value = str(args.get("elementType") or "Door").strip().capitalize()
    if value not in OPENING_TYPES:
        raise ArchicadError("elementType must be one of: %s" % ", ".join(OPENING_TYPES))
    return value


def relabel(result, element_type):
    """The Part 1 tools name their keys after doors; for windows the same keys say 'window'.

    Only the keys of the result and of its rows are renamed. Values (type names, IDs) and the keys of the
    count tables (which are type names) stay as they are.
    """
    if element_type == "Door":
        return result

    def rename(row):
        return {key.replace("door", "window").replace("Door", "Window"): item for key, item in row.items()}

    renamed = rename(result)
    for key, item in renamed.items():
        if isinstance(item, list):
            renamed[key] = [rename(row) if isinstance(row, dict) else row for row in item]
    return renamed


def door_keys(match):
    """Lets a window rule say windowType / windowGuids; inside the server they are the door keys."""
    return {key.replace("window", "door"): item for key, item in match.items()}


DOOR_FIELDS = [
    builtin("General_ElementID"),
    builtin("General_LibraryPartName"),
    builtin("General_Width"),
    builtin("General_Height"),
    builtin("IdAndCategories_ParentId"),
    builtin("General_BottomElevationToProjectZero"),
    builtin("General_BottomElevationToHomeStory"),
]


def load_doors(which="door", port=None, need_rating=True, element_type="Door"):
    """Doors, or windows with element_type="Window"; the rows keep the door key names."""
    fields = list(DOOR_FIELDS)
    if need_rating:
        name, _ = fire_property_id(which, port)
        fields.append(name)
    elements = ac("API.GetElementsByType", {"elementType": element_type}, port)["elements"]
    rows = read_values(elements, fields, port)
    table = storey_table(port)
    doors = []
    for element, row in zip(elements, rows):
        element_id, lib_part, width, height, parent, to_zero, to_story = [plain(v) for v in row[:7]]
        elevation = None
        if to_zero is not None and to_story is not None:
            elevation = round(to_zero - to_story, 3)
        door = {
            "guid": element["elementId"]["guid"],
            "doorId": element_id,
            "doorType": lib_part,
            "width": width,
            "height": height,
            "hostWallId": parent,
            "storey": storey_label(elevation, table),
            "storeyElevation": elevation,
        }
        if need_rating:
            raw = row[7]
            door["fireRating"] = plain(raw)
            # userUndefined = the property applies to the door but holds no value yet
            door["ratingAvailable"] = bool(raw) and raw.get("status") in ("normal", "userUndefined")
        doors.append(door)
    return doors


def count_per_storey(doors):
    counts = {}
    for door in doors:
        entry = counts.setdefault(door["storey"], {"storey": door["storey"], "elevation": door["storeyElevation"],
                                                   "doors": 0, "missing": 0, "notApplicable": 0})
        entry["doors"] += 1
        if not door.get("ratingAvailable", True):
            entry["notApplicable"] += 1  # e.g. an empty opening: it cannot hold a rating, so it is not missing
        elif is_missing(door.get("fireRating")):
            entry["missing"] += 1
    return sorted(counts.values(), key=lambda e: (e["elevation"] is None, e["elevation"] or 0))


def door_scope(doors, args):
    """Leaves out doors on storeys that are not part of the building. Returns (kept doors, number left out)."""
    drop_storeys = {name.strip().lower() for name in args.get("excludeStoreys") or []}
    min_elevation = args.get("minStoreyElevation")
    kept = []
    for door in doors:
        if door["storey"].lower() in drop_storeys:
            continue
        if min_elevation is not None and (door["storeyElevation"] is None
                                          or door["storeyElevation"] < min_elevation):
            continue
        kept.append(door)
    return kept, len(doors) - len(kept)


def needs_rating(door):
    return door.get("ratingAvailable", True) and is_missing(door.get("fireRating"))


def bounding_boxes(elements, port=None):
    boxes = []
    for part in chunks(elements):
        reply = ac("API.Get3DBoundingBoxes", {"elements": part}, port)["boundingBoxes3D"]
        boxes.extend(b.get("boundingBox3D") for b in reply)
    return boxes


def plan_overlap(door_box, wall_box):
    """Area in plan shared by the two boxes; 0 when they do not overlap in plan or in height."""
    dx = min(door_box["xMax"], wall_box["xMax"]) - max(door_box["xMin"], wall_box["xMin"])
    dy = min(door_box["yMax"], wall_box["yMax"]) - max(door_box["yMin"], wall_box["yMin"])
    dz = min(door_box["zMax"], wall_box["zMax"]) - max(door_box["zMin"], wall_box["zMin"])
    if dx <= BBOX_TOLERANCE or dy <= BBOX_TOLERANCE or dz <= 0:
        return 0.0
    return dx * dy


def host_walls(door_guids=None, port=None, element_type="Door"):
    """Links each door to the wall it sits in.

    Archicad reports the host wall of a door only as its Element ID text
    (Parent ID), and many walls share one ID. So the walls are narrowed down by
    Parent ID first, then by geometry: the wall whose 3D bounding box shares
    the largest plan area with the door's box wins. (The door's box includes
    its open leaf, so its centre is usually outside the wall.) A match counts
    as exact when the shared area is about door width x wall thickness and no
    other wall comes close. Bounding boxes are axis-aligned, so doors in
    slanted walls come out as ambiguous.

    Only walls whose ID is the Parent ID of one of the doors are measured, so
    the cost follows the number of doors, not the size of the model.
    """
    doors = load_doors(port=port, need_rating=False, element_type=element_type)
    if door_guids:
        wanted = {g.upper() for g in door_guids}
        doors = [d for d in doors if d["guid"].upper() in wanted]
    if not doors:
        return []

    walls = ac("API.GetElementsByType", {"elementType": "Wall"}, port)["elements"]
    wall_ids = [plain(row[0]) or "" for row in read_values(walls, [builtin("General_ElementID")], port)]
    needed = {d["hostWallId"] or "" for d in doors}
    walls = [w for w, wid in zip(walls, wall_ids) if wid in needed]
    wall_ids = [wid for wid in wall_ids if wid in needed]
    wall_rows = read_values(walls, [builtin("General_Thickness"), WALL_FIRE_PROPERTY], port)
    wall_boxes = bounding_boxes(walls, port)
    by_id = {}
    for wall, wid, row, box in zip(walls, wall_ids, wall_rows, wall_boxes):
        if box:
            by_id.setdefault(wid, []).append((wall, row, box))
    door_boxes = bounding_boxes([{"elementId": {"guid": d["guid"]}} for d in doors], port)

    results = []
    for door, door_box in zip(doors, door_boxes):
        entry = {"doorGuid": door["guid"], "doorId": door["doorId"], "doorType": door["doorType"],
                 "storey": door["storey"], "hostWallId": door["hostWallId"]}
        same_id = by_id.get(door["hostWallId"] or "", [])
        pool = []
        if door_box:
            for wall, row, wall_box in same_id:
                area = plan_overlap(door_box, wall_box)
                if area > 0:
                    pool.append((wall, row, area))
        pool.sort(key=lambda c: c[2], reverse=True)
        if pool:
            wall, row, area = pool[0]
            thickness = plain(row[0])
            clear_winner = len(pool) == 1 or pool[1][2] < 0.5 * area
            if thickness and door["width"]:
                right_size = area >= 0.7 * door["width"] * thickness
            else:
                right_size = True  # nothing to compare against
            entry.update({
                "hostWallGuid": wall["elementId"]["guid"],
                "hostWallThickness": thickness,
                "hostWallFireResistance": plain(row[1]),
                "match": "exact" if clear_winner and right_size else "ambiguous",
                "candidateWalls": len(pool),
            })
        else:
            if not door_box:
                reason = "Archicad returned no 3D bounding box for this door"
            elif not door["hostWallId"]:
                reason = "the door has no Parent ID and no wall with an empty ID overlaps it"
            elif not same_id:
                reason = ("no wall has the Element ID '%s'; the door may sit in a curtain wall or another "
                          "element type" % door["hostWallId"])
            else:
                reason = "none of the %d walls with ID '%s' overlaps the door" % (len(same_id), door["hostWallId"])
            reason = reason.replace("door", element_type.lower())
            entry.update({"hostWallGuid": None, "match": "not found", "candidateWalls": 0, "reason": reason})
        results.append(entry)
    return results


def limited(rows, args):
    limit = int(args.get("limit", DEFAULT_LIMIT))
    return rows[:limit], max(0, len(rows) - limit)


def tally(rows, *keys):
    counts = {}
    for row in rows:
        label = " | ".join(str(row.get(key)) for key in keys)
        counts[label] = counts.get(label, 0) + 1
    return counts


# ---------------------------------------------------------------- walls (Part 2, read-only)

WALL_FIELDS = [
    builtin("General_ElementID"),
    builtin("ModelView_LayerName"),
    builtin("ModelView_IsLayerVisible"),
    builtin("General_StructureType"),
    builtin("Construction_CompositeName"),
    builtin("Construction_ProfileName"),
    builtin("General_Thickness"),
    builtin("General_Height"),
    builtin("Wall_ReferenceLineLength"),
    builtin("Wall_CenterLength"),
    builtin("Wall_GrossInsideSurfaceArea"),
    builtin("Wall_GrossOutsideSurfaceArea"),
    builtin("Wall_NetInsideSurfaceArea"),
    builtin("Wall_NetOutsideSurfaceArea"),
    builtin("Category_RenovationStatus"),
    builtin("General_BottomElevationToProjectZero"),
    builtin("General_BottomElevationToHomeStory"),
    WALL_FIRE_PROPERTY,
]
NO_FIRE_RATING = "not set"
GROUP_KEYS = {
    "layer": ("layer",),
    "wallType": ("wallType",),
    "layer+wallType": ("layer", "wallType"),
    "layer+storey": ("layer", "storey"),
    "fireResistance": ("fireResistance",),
    "wallType+fireResistance": ("wallType", "fireResistance"),
    "storey+fireResistance": ("storey", "fireResistance"),
}
AREA_BASES = ("lengthXheight", "gross", "net")
LENGTH_BASES = ("reference", "center")


def mean(a, b):
    values = [v for v in (a, b) if v is not None]
    return sum(values) / len(values) if values else None


def load_walls(port=None):
    """Every wall of the model with its layer, type, storey and quantities (metres, m2)."""
    elements = ac("API.GetElementsByType", {"elementType": "Wall"}, port)["elements"]
    rows = read_values(elements, WALL_FIELDS, port)
    table = storey_table(port)
    walls = []
    for element, row in zip(elements, rows):
        (wall_id, layer, visible, structure, composite, profile, thickness, height, ref_length, center_length,
         gross_in, gross_out, net_in, net_out, renovation, to_zero, to_story, fire) = [plain(v) for v in row]
        # Archicad gives no building material name for basic walls through this API, so a basic wall is
        # told apart by its thickness; composite and profile walls by their name.
        if composite:
            wall_type = composite
        elif profile:
            wall_type = profile
        elif thickness is not None:
            wall_type = "%s %d mm" % (structure or "Wall", round(thickness * 1000))
        else:
            wall_type = structure or "unknown"
        elevation = None
        if to_zero is not None and to_story is not None:
            elevation = round(to_zero - to_story, 3)
        walls.append({
            "guid": element["elementId"]["guid"],
            "wallId": wall_id,
            "layer": (layer or "").strip() or "no layer",
            "layerVisible": visible is not False,
            "wallType": wall_type,
            "thickness": thickness,
            "height": height,
            "referenceLength": ref_length,
            "centerLength": center_length,
            "grossArea": mean(gross_in, gross_out),   # one face, openings not deducted
            "netArea": mean(net_in, net_out),         # one face, openings deducted
            "renovation": renovation,
            "fireResistance": NO_FIRE_RATING if is_missing(fire) else str(fire).strip(),
            "storey": storey_label(elevation, table),
            "storeyElevation": elevation,
        })
    return walls


def wall_filter(walls, args):
    """Applies the exclusions the user agreed to. Returns (kept walls, what was left out and why)."""
    include_hidden = bool(args.get("includeHiddenLayers", False))
    drop_layers = {name.strip().lower() for name in args.get("excludeLayers") or []}
    drop_status = {name.strip().lower() for name in args.get("excludeRenovationStatus") or []}
    min_height = args.get("minHeight")
    drop_storeys = {name.strip().lower() for name in args.get("excludeStoreys") or []}
    min_elevation = args.get("minStoreyElevation")
    kept, dropped = [], {}

    def drop(wall, reason):
        entry = dropped.setdefault((reason, wall["layer"]), {"reason": reason, "layer": wall["layer"],
                                                             "walls": 0, "referenceLength": 0.0})
        entry["walls"] += 1
        entry["referenceLength"] += wall["referenceLength"] or 0.0

    for wall in walls:
        if not wall["layerVisible"] and not include_hidden:
            drop(wall, "hidden layer")
        elif wall["layer"].lower() in drop_layers:
            drop(wall, "layer excluded")
        elif wall["storey"].lower() in drop_storeys:
            drop(wall, "storey excluded")
        elif min_elevation is not None and (wall["storeyElevation"] is None
                                            or wall["storeyElevation"] < min_elevation):
            drop(wall, "storey below %s m" % min_elevation)
        elif (wall["renovation"] or "").lower() in drop_status:
            drop(wall, "renovation status %s" % wall["renovation"])
        elif min_height is not None and (wall["height"] or 0) < min_height:
            drop(wall, "lower than %s m" % min_height)
        else:
            kept.append(wall)
    left_out = sorted(dropped.values(), key=lambda e: (e["reason"], e["layer"]))
    for entry in left_out:
        entry["referenceLength"] = round(entry["referenceLength"], 3)
    return kept, left_out


def wall_groups(walls, group_by):
    """Totals per group. Sums always cover every wall passed in."""
    keys = GROUP_KEYS.get(group_by)
    if keys is None:
        raise ArchicadError("groupBy must be one of: %s" % ", ".join(GROUP_KEYS))
    groups = {}
    for wall in walls:
        label = tuple(wall[key] for key in keys)
        group = groups.get(label)
        if group is None:
            group = groups[label] = dict(zip(keys, label))
            group.update({"walls": 0, "referenceLength": 0.0, "centerLength": 0.0, "grossArea": 0.0, "netArea": 0.0,
                          "heights": {}, "layerVisible": set(), "incomplete": 0})
        group["walls"] += 1
        group["layerVisible"].add(wall["layerVisible"])
        if None in (wall["referenceLength"], wall["centerLength"], wall["height"], wall["grossArea"],
                    wall["netArea"]):
            group["incomplete"] += 1
        for key in ("referenceLength", "centerLength", "grossArea", "netArea"):
            group[key] += wall[key] or 0.0
        if wall["height"] is not None:
            height = round(wall["height"], 3)
            group["heights"][height] = group["heights"].get(height, 0.0) + (wall["referenceLength"] or 0.0)
    result = []
    for label in sorted(groups):
        group = groups[label]
        heights = group.pop("heights")
        visible = group.pop("layerVisible")
        group["layerVisible"] = "mixed" if len(visible) > 1 else visible.pop()
        for key in ("referenceLength", "centerLength"):
            group[key] = round(group[key], 3)
        for key in ("grossArea", "netArea"):
            group[key] = round(group[key], 2)
        if heights:
            group["heightMin"] = min(heights)
            group["heightMax"] = max(heights)
            # the height most of the length has, so the user can confirm one height per group
            group["heightMostCommon"] = max(heights, key=heights.get)
            group["distinctHeights"] = len(heights)
        if not group["incomplete"]:
            del group["incomplete"]
        result.append(group)
    return result


WALL_NOTES = {
    "units": "lengths in metres, areas in m2",
    "referenceLength": "length of the wall's reference line",
    "centerLength": "length along the wall centre, corners not counted twice",
    "grossArea": "one face of the wall, door and window openings NOT deducted (mean of inside and outside face)",
    "netArea": "one face of the wall, openings deducted (mean of inside and outside face)",
    "wallType": "composite or profile name; a basic wall is named by its thickness because Archicad does not "
                "report its building material through this API",
    "fireResistance": "GENERAL RATINGS > Fire Resistance Rating of the wall; 'not set' when it is empty or the "
                      "project has no such property",
}


def wall_fire_property_status(port=None):
    """Tells whether 'not set' means an empty value or a project without the property at all."""
    label = property_label(WALL_FIRE_PROPERTY)
    pid = ac("API.GetPropertyIds", {"properties": [WALL_FIRE_PROPERTY]}, port)["properties"][0]
    if "propertyId" in pid:
        return "%s exists in this project; 'not set' means the wall has no value" % label
    return ("%s does NOT exist in this project, so every wall shows 'not set'. Add the property in Archicad "
            "(Options > Property Manager) or check the walls' fire rating another way." % label)


def tool_wall_quantities(args):
    port = select_port(args.get("port"))
    group_by = args.get("groupBy", "layer")
    walls = load_walls(port)
    kept, left_out = wall_filter(walls, args)
    result = {
        "port": port,
        "totalWallsInModel": len(walls),
        "wallsMeasured": len(kept),
        "groupBy": group_by,
        "groups": wall_groups(kept, group_by),
        "totals": {
            "referenceLength": round(sum(w["referenceLength"] or 0.0 for w in kept), 3),
            "centerLength": round(sum(w["centerLength"] or 0.0 for w in kept), 3),
            "grossArea": round(sum(w["grossArea"] or 0.0 for w in kept), 2),
            "netArea": round(sum(w["netArea"] or 0.0 for w in kept), 2),
        },
        "leftOut": left_out,
        "renovationStatus": tally(kept, "renovation"),
        "fireResistance": tally(kept, "fireResistance"),
        "fireResistanceProperty": wall_fire_property_status(port),
        "toConfirm": [
            "Hidden layers: walls on hidden layers are left out unless includeHiddenLayers is true. See leftOut.",
            "Layers that are not real walls (furniture, ceilings, existing or old buildings): name them in "
            "excludeLayers.",
            "Storeys that are not part of the building (module or library source storeys): name them in "
            "excludeStoreys or set minStoreyElevation. Group by layer+storey to see them.",
            "Heights: where heightMin and heightMax differ, agree whether to price the modelled heights or one "
            "height per rate.",
            "Area basis: length x height, gross face area, or net face area (openings deducted).",
        ],
        "notes": WALL_NOTES,
    }
    if args.get("listWalls"):
        columns = ("wallId", "layer", "wallType", "storey", "referenceLength", "centerLength", "height",
                   "thickness", "fireResistance", "grossArea", "netArea", "layerVisible", "renovation", "guid")
        shown, hidden = limited([{key: wall[key] for key in columns} for wall in kept], args)
        result["walls"] = shown
        result["notShown"] = hidden
    return result


RATE_MATCH_KEYS = ("layer", "layerContains", "wallType", "wallTypeContains", "minThickness", "maxThickness")


def rate_for(wall, rates):
    for rate in rates:
        if "layer" in rate and rate["layer"].strip().lower() != wall["layer"].lower():
            continue
        if "wallType" in rate and rate["wallType"].strip().lower() != wall["wallType"].lower():
            continue
        if "wallTypeContains" in rate and rate["wallTypeContains"].strip().lower() not in wall["wallType"].lower():
            continue
        if "layerContains" in rate and rate["layerContains"].strip().lower() not in wall["layer"].lower():
            continue
        if "minThickness" in rate or "maxThickness" in rate:
            mm = None if wall["thickness"] is None else round(wall["thickness"] * 1000)
            if mm is None or mm < rate.get("minThickness", 0) or mm > rate.get("maxThickness", float("inf")):
                continue
        return rate
    return None


def tool_price_walls(args):
    port = select_port(args.get("port"))
    rates = args.get("rates") or []
    if not rates:
        raise ArchicadError("Give at least one rate, e.g. {'layer': 'Interior - Partition', 'low': 40, 'mid': 55, "
                            "'high': 70}. Run get_wall_quantities first to see the layers and wall types.")
    for rate in rates:
        if not isinstance(rate.get("mid"), (int, float)) or isinstance(rate.get("mid"), bool) or rate["mid"] < 0:
            raise ArchicadError("Every rate needs a 'mid' price per m2 (a number, not negative): %r" % (rate,))
    area_basis = args.get("areaBasis", "lengthXheight")
    length_basis = args.get("lengthBasis", "reference")
    if area_basis not in AREA_BASES:
        raise ArchicadError("areaBasis must be one of: %s" % ", ".join(AREA_BASES))
    if length_basis not in LENGTH_BASES:
        raise ArchicadError("lengthBasis must be one of: %s" % ", ".join(LENGTH_BASES))
    group_by = args.get("groupBy", "layer")
    keys = ("rate",) if group_by == "rate" else GROUP_KEYS.get(group_by)
    if keys is None:
        raise ArchicadError("groupBy must be one of: %s, rate" % ", ".join(GROUP_KEYS))

    walls = load_walls(port)
    kept, left_out = wall_filter(walls, args)
    length_key = "referenceLength" if length_basis == "reference" else "centerLength"
    rows, unpriced, unmeasured = {}, [], []
    used = set()
    for wall in kept:
        rate = rate_for(wall, rates)
        if rate is None:
            unpriced.append(wall)
            continue
        length = wall[length_key]
        height = rate.get("height", wall["height"])
        if area_basis == "lengthXheight":
            area = None if length is None or height is None else length * height
        else:
            area = wall["grossArea" if area_basis == "gross" else "netArea"]
        if area is None or length is None:
            unmeasured.append(wall)
            continue
        used.add(id(rate))
        low, mid, high = rate.get("low", rate["mid"]), rate["mid"], rate.get("high", rate["mid"])
        rate_name = rate.get("label") or " / ".join(
            "%s=%s" % (key, rate[key]) for key in RATE_MATCH_KEYS if key in rate) or "any wall"
        label = tuple(rate_name if key == "rate" else wall[key] for key in keys) + (low, mid, high)
        row = rows.get(label)
        if row is None:
            row = rows[label] = dict(zip(keys, label))
            row.update({"walls": 0, "length": 0.0, "area": 0.0, "rateLow": low, "rateMid": mid, "rateHigh": high,
                        "costLow": 0.0, "costMid": 0.0, "costHigh": 0.0})
            if area_basis == "lengthXheight":
                row["height"] = "%s m (agreed)" % rate["height"] if "height" in rate else "as modelled"
        row["walls"] += 1
        row["length"] += length
        row["area"] += area
        row["costLow"] += area * low
        row["costMid"] += area * mid
        row["costHigh"] += area * high
    table = [rows[label] for label in sorted(rows, key=lambda l: tuple(str(part) for part in l))]
    totals = {"walls": 0, "length": 0.0, "area": 0.0, "costLow": 0.0, "costMid": 0.0, "costHigh": 0.0}
    for row in table:
        for key in totals:
            totals[key] += row[key]
        row["length"] = round(row["length"], 3)
        for key in ("area", "costLow", "costMid", "costHigh"):
            row[key] = round(row[key], 2)
    totals["length"] = round(totals["length"], 3)
    for key in ("area", "costLow", "costMid", "costHigh"):
        totals[key] = round(totals[key], 2)
    return {
        "port": port,
        "currency": args.get("currency", "USD"),
        "costTable": table,
        "totals": totals,
        "unpriced": wall_groups(unpriced, "layer+wallType"),
        "unpricedWalls": len(unpriced),
        "unmeasuredWalls": [{"wallId": w["wallId"], "layer": w["layer"], "guid": w["guid"]} for w in unmeasured],
        "unusedRates": [rate for rate in rates if id(rate) not in used],
        "leftOut": left_out,
        "assumptions": {
            "areaBasis": {"lengthXheight": "area = %s length x height" % length_basis,
                          "gross": "gross face area from Archicad, openings not deducted",
                          "net": "net face area from Archicad, openings deducted"}[area_basis],
            "lengthBasis": WALL_NOTES[length_key],
            "rates": "price per m2 of wall face; where low or high is not given the mid rate is used; the first "
                     "matching rate wins",
            "hiddenLayers": "included" if args.get("includeHiddenLayers") else "left out",
            "excludeLayers": args.get("excludeLayers") or [],
            "excludeRenovationStatus": args.get("excludeRenovationStatus") or [],
            "minHeight": args.get("minHeight"),
            "excludeStoreys": args.get("excludeStoreys") or [],
            "minStoreyElevation": args.get("minStoreyElevation"),
            "model": "read-only, nothing in the model was changed",
        },
        "next": "If unpriced or unusedRates is not empty, a layer or wall type name does not match: fix the rates "
                "and run again. Otherwise show costTable, totals and assumptions to the user.",
    }


# ---------------------------------------------------------------- tools

def tool_status(args):
    instances = []
    for port, info in find_instances():
        entry = {"port": port, "archicad": info}
        try:
            entry["doors"] = len(ac("API.GetElementsByType", {"elementType": "Door"}, port)["elements"])
            entry["windows"] = len(ac("API.GetElementsByType", {"elementType": "Window"}, port)["elements"])
            entry["walls"] = len(ac("API.GetElementsByType", {"elementType": "Wall"}, port)["elements"])
        except ArchicadError as error:
            entry["error"] = str(error)
        instances.append(entry)
    if not instances:
        raise ArchicadError("No running Archicad found on ports %d-%d. Open Archicad with a project first."
                            % (PORTS[0], PORTS[-1]))
    result = {"instances": instances, "serverVersion": SERVER_VERSION}
    try:
        result["usingPort"] = select_port(args.get("port"))
    except ArchicadError as error:
        result["usingPort"] = None
        result["note"] = str(error)
    return result


def tool_find_missing(args):
    port = select_port(args.get("port"))
    which = args.get("property", "door")
    element_type = opening_type(args)
    doors, out_of_scope = door_scope(load_doors(which, port, element_type=element_type), args)
    missing = [d for d in doors if needs_rating(d)]
    shown, hidden = limited(missing, args)
    return relabel({
        "port": port,
        "elementType": element_type,
        "property": property_label(fire_property(which)),
        "totalDoors": len(doors),
        "totalMissing": len(missing),
        "notApplicable": sum(1 for d in doors if not d["ratingAvailable"]),
        "doorsOnExcludedStoreys": out_of_scope,
        "perStorey": count_per_storey(doors),
        "missingByDoorType": tally(missing, "doorType"),
        "missingDoors": shown,
        "notShown": hidden,
    }, element_type)


def tool_host_walls(args):
    port = select_port(args.get("port"))
    element_type = opening_type(args)
    results = host_walls(args.get("doorGuids") or args.get("windowGuids"), port, element_type)
    shown, hidden = limited(results, args)
    return relabel({
        "port": port,
        "elementType": element_type,
        "totalDoors": len(results),
        "matches": tally(results, "match"),
        "byDoorTypeAndWall": tally(results, "doorType", "hostWallId", "hostWallThickness", "hostWallFireResistance"),
        "doors": shown,
        "notShown": hidden,
        "method": "Parent ID of the door + largest plan overlap of the door's and the wall's 3D bounding "
                  "boxes".replace("door", element_type.lower()),
    }, element_type)


def property_definition(which, port):
    _, pid = fire_property_id(which, port)
    definition = ac("API.GetDetailsOfProperties", {"properties": [pid]}, port)["propertyDefinitions"][0]
    definition = definition.get("propertyDefinition", {})
    values = [v["enumValue"]["displayValue"] for v in definition.get("possibleEnumValues", [])]
    return pid, definition, values


def type_key(name):
    """Door type without the library version at its end: 'Double Door 27' and 'Double Door' are the same type.

    The comparison stays exact after that, so a rule for 'Door' never catches 'Double Door'.
    """
    return re.sub(r"\s+\d+$", "", (name or "").strip()).lower()


def rule_matches(match, door):
    if "doorGuids" in match and door["guid"].upper() not in {g.upper() for g in match["doorGuids"]}:
        return False
    if "doorType" in match and type_key(door["doorType"]) != type_key(match["doorType"]):
        return False
    if "hostWallId" in match and (door["hostWallId"] or "").lower() != match["hostWallId"].lower():
        return False
    if "storey" in match:
        elevation = "no storey" if door["storeyElevation"] is None else "%+.2f m" % door["storeyElevation"]
        if match["storey"].strip().lower() not in (door["storey"].lower(), elevation.lower()):
            return False
    if "minWidth" in match and (door["width"] is None or door["width"] < match["minWidth"]):
        return False
    return True


def tool_preview(args):
    port = select_port(args.get("port"))
    which = args.get("property", "door")
    element_type = opening_type(args)
    overwrite = bool(args.get("overwrite", False))
    rules = args.get("rules") or []
    if not rules:
        raise ArchicadError("Give at least one rule, e.g. {'match': {'doorType': 'Door 27'}, 'value': 'EI 30'}")
    pid, definition, allowed = property_definition(which, port)
    if definition.get("isEditable") is False:
        raise ArchicadError("The property '%s' is read-only in Archicad." % property_label(fire_property(which)))
    value_type = definition.get("type")
    if value_type not in ("string", "singleEnum"):
        raise ArchicadError("The property '%s' has type %s; only text and single-choice properties are supported."
                            % (property_label(fire_property(which)), value_type))
    for rule in rules:
        if not str(rule.get("value", "")).strip():
            raise ArchicadError("Every rule needs a non-empty 'value'.")
        if allowed and rule.get("value") not in allowed:
            raise ArchicadError("Value %r is not allowed for this property. Allowed: %s" % (rule.get("value"), allowed))

    doors, out_of_scope = door_scope(load_doors(which, port, element_type=element_type), args)
    changes, skipped = [], []
    for door in doors:
        if not is_missing(door["fireRating"]) and not overwrite:
            continue
        rule = next((r for r in rules if rule_matches(door_keys(r.get("match") or {}), door)), None)
        if rule is None:
            skipped.append({"doorId": door["doorId"], "doorGuid": door["guid"], "doorType": door["doorType"],
                            "reason": "no rule matches"})
        elif not door["ratingAvailable"]:
            skipped.append({"doorId": door["doorId"], "doorGuid": door["guid"], "doorType": door["doorType"],
                            "reason": "property is not available for this %s" % element_type.lower()})
        else:
            changes.append({"doorGuid": door["guid"], "doorId": door["doorId"], "doorType": door["doorType"],
                            "storey": door["storey"], "hostWallId": door["hostWallId"],
                            "before": door["fireRating"], "after": rule["value"]})
    preview_id = uuid.uuid4().hex[:8]
    _previews[preview_id] = {"which": which, "port": port, "propertyId": pid, "valueType": value_type,
                             "changes": changes, "elementType": element_type,
                             "scope": {key: args[key] for key in ("excludeStoreys", "minStoreyElevation")
                                       if key in args}}
    shown, hidden = limited(changes, args)
    return relabel({
        "previewId": preview_id,
        "port": port,
        "elementType": element_type,
        "property": property_label(fire_property(which)),
        "willChange": len(changes),
        "summary": tally(changes, "doorType", "after"),
        "doorsOnExcludedStoreys": out_of_scope,
        "changes": shown,
        "notShown": hidden,
        "skipped": skipped[:int(args.get("limit", DEFAULT_LIMIT))],
        "skippedTotal": len(skipped),
        "skippedReasons": tally(skipped, "reason"),
        "unmatchedDoorTypes": tally([s for s in skipped if s["reason"] == "no rule matches"], "doorType"),
        "perStoreyBefore": count_per_storey(doors) if args.get("includePerStorey") else "pass includePerStorey=true",
        "next": "If unmatchedDoorTypes is not empty, fix the rules and preview again. Otherwise show this to the "
                "user and, only after they confirm, call apply_fire_rating with this previewId.",
    }, element_type)


def tool_apply(args):
    preview = _previews.get(args.get("previewId"))
    if preview is None or preview.get("kind"):  # rename and wall previews have their own apply tool
        raise ArchicadError("Unknown previewId. Run preview_fire_rating first and let the user confirm it.")
    if not args.get("confirmedByUser"):
        raise ArchicadError("Not applied: the user has to confirm the preview first (confirmedByUser=true).")
    port = preview["port"]  # always the instance the preview was made on
    writes = []
    for change in preview["changes"]:
        if preview["valueType"] == "singleEnum":
            value = {"type": "singleEnum", "status": "normal",
                     "value": {"type": "displayValue", "displayValue": change["after"]}}
        else:
            value = {"type": "string", "status": "normal", "value": change["after"]}
        writes.append({"elementId": {"guid": change["doorGuid"]}, "propertyId": preview["propertyId"]["propertyId"],
                       "propertyValue": value})
    failed = []
    done = 0
    for part in chunks(writes):
        results = ac("API.SetPropertyValuesOfElements", {"elementPropertyValues": part}, port)["executionResults"]
        for change, result in zip(preview["changes"][done:done + len(part)], results):
            if not result.get("success"):
                failed.append({"doorId": change["doorId"], "doorGuid": change["doorGuid"],
                               "error": result.get("error", {}).get("message")})
        done += len(part)
    del _previews[args["previewId"]]
    element_type = preview.get("elementType", "Door")
    doors, _ = door_scope(load_doors(preview["which"], port, element_type=element_type), preview.get("scope", {}))
    now = {d["guid"]: d["fireRating"] for d in doors}
    return relabel({
        "port": port,
        "elementType": element_type,
        "written": len(writes) - len(failed),
        "failedTotal": len(failed),
        "failedReasons": tally(failed, "error"),  # e.g. Teamwork: the doors are not reserved by this user
        "failed": failed[:DEFAULT_LIMIT],
        "perStoreyAfter": count_per_storey(doors),
        "stillMissing": sum(1 for d in doors if needs_rating(d)),
        "notApplicable": sum(1 for d in doors if not d["ratingAvailable"]),
        # read back from the model; 'before' is kept so the change can be reversed with another preview
        "changes": [dict(c, now=now.get(c["doorGuid"])) for c in preview["changes"][:DEFAULT_LIMIT]],
    }, element_type)


# ---------------------------------------------------------------- renaming (Element ID)

RENAME_TYPES = ("Door", "Window", "Wall")
ELEMENT_ID = builtin("General_ElementID")


def element_ids(element_type, port=None):
    """[(guid, Element ID)] of every element of this type."""
    if element_type not in RENAME_TYPES:
        raise ArchicadError("elementType must be one of: %s" % ", ".join(RENAME_TYPES))
    elements = ac("API.GetElementsByType", {"elementType": element_type}, port)["elements"]
    rows = read_values(elements, [ELEMENT_ID], port)
    return [(element["elementId"]["guid"], plain(row[0]) or "") for element, row in zip(elements, rows)]


def shared_ids(ids):
    """{Element ID: number of elements} for every ID held by more than one element."""
    counts = {}
    for element_id in ids:
        counts[element_id] = counts.get(element_id, 0) + 1
    return {element_id: count for element_id, count in sorted(counts.items()) if count > 1}


def tool_preview_rename(args):
    port = select_port(args.get("port"))
    element_type = args.get("elementType", "Door")
    renames = args.get("renames") or []
    if not renames:
        raise ArchicadError("Give at least one rename, e.g. {'guid': '<element guid>', 'newId': 'D - 23'}. The "
                            "guids come from find_doors_missing_fire_rating or get_wall_quantities(listWalls=true).")
    pid = ac("API.GetPropertyIds", {"properties": [ELEMENT_ID]}, port)["properties"][0]
    if "propertyId" not in pid:
        raise ArchicadError("This Archicad does not expose the Element ID property through its API.")
    definition = ac("API.GetDetailsOfProperties", {"properties": [pid]}, port)["propertyDefinitions"][0]
    if definition.get("propertyDefinition", {}).get("isEditable") is False:
        raise ArchicadError("The Element ID is read-only through the Archicad API in this version.")

    current = {guid.upper(): element_id for guid, element_id in element_ids(element_type, port)}
    wanted, problems = {}, []
    for rename in renames:
        guid = str(rename.get("guid", "")).strip().upper()
        new_id = str(rename.get("newId", "")).strip()
        if guid not in current:
            problems.append({"guid": rename.get("guid"), "problem": "no %s has this guid" % element_type})
        elif not new_id:
            problems.append({"guid": guid, "problem": "newId is empty"})
        elif guid in wanted:
            problems.append({"guid": guid, "problem": "listed more than once"})
        else:
            wanted[guid] = new_id
    after = dict(current)
    after.update(wanted)
    shared_after = shared_ids(after.values())
    changes = []
    for guid, new_id in wanted.items():
        if new_id == current[guid]:
            continue  # already has this ID
        change = {"guid": guid, "elementType": element_type, "before": current[guid], "after": new_id}
        if new_id in shared_after:
            change["conflict"] = "%d elements would share this ID" % shared_after[new_id]
            if not args.get("allowDuplicates"):
                problems.append({"guid": guid, "problem": "the ID '%s' would be shared by %d elements"
                                                          % (new_id, shared_after[new_id])})
        changes.append(change)

    result = {
        "port": port,
        "elementType": element_type,
        "willChange": len(changes),
        "changes": changes,
        "sharedIdsNow": shared_ids(current.values()),
        "sharedIdsAfter": shared_after,
        "problems": problems,
    }
    if problems or not changes:
        result["previewId"] = None
        result["next"] = ("Nothing to apply: fix the problems and preview again. Pass allowDuplicates=true only if "
                          "the user wants several elements to share an ID." if problems else
                          "Nothing to apply: every element already has the requested ID.")
        return result
    preview_id = uuid.uuid4().hex[:8]
    _previews[preview_id] = {"kind": "rename", "port": port, "elementType": element_type,
                             "propertyId": pid["propertyId"], "changes": changes}
    result["previewId"] = preview_id
    result["next"] = ("Show this table to the user and, only after they confirm, call apply_rename_elements with "
                      "this previewId.")
    return result


def tool_apply_rename(args):
    preview = _previews.get(args.get("previewId"))
    if preview is None or preview.get("kind") != "rename":
        raise ArchicadError("Unknown previewId. Run preview_rename_elements first and let the user confirm it.")
    if not args.get("confirmedByUser"):
        raise ArchicadError("Not applied: the user has to confirm the preview first (confirmedByUser=true).")
    port = preview["port"]  # always the instance the preview was made on
    element_type = preview["elementType"]
    current = {guid.upper(): element_id for guid, element_id in element_ids(element_type, port)}
    stale = [c for c in preview["changes"] if current.get(c["guid"]) != c["before"]]
    if stale:
        del _previews[args["previewId"]]
        raise ArchicadError("Not applied: %d element(s) were changed or deleted in Archicad since the preview "
                            "(e.g. %s). Preview again." % (len(stale), stale[0]["guid"]))
    writes = [{"elementId": {"guid": change["guid"]}, "propertyId": preview["propertyId"],
               "propertyValue": {"type": "string", "status": "normal", "value": change["after"]}}
              for change in preview["changes"]]
    failed = []
    done = 0
    for part in chunks(writes):
        results = ac("API.SetPropertyValuesOfElements", {"elementPropertyValues": part}, port)["executionResults"]
        for change, result in zip(preview["changes"][done:done + len(part)], results):
            if not result.get("success"):
                failed.append({"guid": change["guid"], "before": change["before"], "after": change["after"],
                               "error": result.get("error", {}).get("message")})
        done += len(part)
    del _previews[args["previewId"]]
    now = {guid.upper(): element_id for guid, element_id in element_ids(element_type, port)}
    renamed = [dict(change, now=now.get(change["guid"])) for change in preview["changes"]]
    return {
        "port": port,
        "elementType": element_type,
        "written": sum(1 for change in renamed if change["now"] == change["after"]),
        "failedTotal": len(failed),
        "failed": failed[:DEFAULT_LIMIT],
        "renamed": renamed,   # 'before' is kept so the rename can be reversed with another preview
        "sharedIdsAfter": shared_ids(now.values()),
    }


# ---------------------------------------------------------------- wall fire rating (write)

def wall_rule_matches(match, wall, door_hosts):
    if "wallGuids" in match and wall["guid"].upper() not in {g.upper() for g in match["wallGuids"]}:
        return False
    if "wallId" in match and (wall["wallId"] or "").lower() != match["wallId"].lower():
        return False
    if "layer" in match and wall["layer"].lower() != match["layer"].strip().lower():
        return False
    if "layerContains" in match and match["layerContains"].strip().lower() not in wall["layer"].lower():
        return False
    if "wallType" in match and wall["wallType"].lower() != match["wallType"].strip().lower():
        return False
    if "wallTypeContains" in match and match["wallTypeContains"].strip().lower() not in wall["wallType"].lower():
        return False
    thickness_mm = None if wall["thickness"] is None else wall["thickness"] * 1000
    if "minThickness" in match and (thickness_mm is None or thickness_mm < match["minThickness"] - 0.5):
        return False
    if "maxThickness" in match and (thickness_mm is None or thickness_mm > match["maxThickness"] + 0.5):
        return False
    if "storey" in match:
        elevation = "no storey" if wall["storeyElevation"] is None else "%+.2f m" % wall["storeyElevation"]
        if match["storey"].strip().lower() not in (wall["storey"].lower(), elevation.lower()):
            return False
    if "hasDoor" in match and (wall["guid"].upper() in door_hosts) != bool(match["hasDoor"]):
        return False
    return True


def tool_preview_wall_fire_rating(args):
    port = select_port(args.get("port"))
    which = args.get("property", "general")
    overwrite = bool(args.get("overwrite", False))
    rules = args.get("rules") or []
    if not rules:
        raise ArchicadError("Give at least one rule, e.g. {'match': {'hasDoor': true}, 'value': 'EI 30'}")
    pid, definition, allowed = property_definition(which, port)
    label = property_label(fire_property(which))
    if definition.get("isEditable") is False:
        raise ArchicadError("The property '%s' is read-only in Archicad." % label)
    value_type = definition.get("type")
    if value_type not in ("string", "singleEnum"):
        raise ArchicadError("The property '%s' has type %s; only text and single-choice properties are supported."
                            % (label, value_type))
    for rule in rules:
        if not str(rule.get("value", "")).strip():
            raise ArchicadError("Every rule needs a non-empty 'value'.")
        if allowed and rule.get("value") not in allowed:
            raise ArchicadError(
                "Value %r is not in the option list of '%s'. Allowed: %s. Archicad's API cannot add options: add "
                "it in Options > Property Manager (or use a free-text property) and preview again."
                % (rule.get("value"), label, allowed))

    # Current rating of the chosen property, read for every wall (it may differ from the 'general' one that
    # load_walls reports).
    walls = load_walls(port)
    current = read_values([{"elementId": {"guid": w["guid"]}} for w in walls], [fire_property(which)], port)
    for wall, row in zip(walls, current):
        text = plain(row[0])
        wall["current"] = NO_FIRE_RATING if is_missing(text) else str(text).strip()
    kept, left_out = wall_filter(walls, args)

    door_hosts = set()
    if any("hasDoor" in (r.get("match") or {}) for r in rules):
        door_hosts = {h["hostWallGuid"].upper() for h in host_walls(port=port) if h.get("hostWallGuid")}

    changes, skipped = [], []
    for wall in kept:
        if wall["current"] != NO_FIRE_RATING and not overwrite:
            continue
        rule = next((r for r in rules if wall_rule_matches(r.get("match") or {}, wall, door_hosts)), None)
        if rule is None:
            skipped.append({"wallId": wall["wallId"], "wallGuid": wall["guid"], "wallType": wall["wallType"],
                            "reason": "no rule matches"})
        elif wall["current"] == rule["value"]:
            continue  # already has this rating
        else:
            changes.append({"wallGuid": wall["guid"], "wallId": wall["wallId"], "wallType": wall["wallType"],
                            "layer": wall["layer"], "storey": wall["storey"],
                            "before": wall["current"], "after": rule["value"]})
    preview_id = uuid.uuid4().hex[:8]
    _previews[preview_id] = {"kind": "wallFire", "which": which, "port": port, "propertyId": pid,
                             "valueType": value_type, "changes": changes}
    shown, hidden = limited(changes, args)
    return {
        "previewId": preview_id,
        "port": port,
        "property": label,
        "willChange": len(changes),
        "summary": tally(changes, "wallType", "before", "after"),
        "leftOut": left_out,
        "changes": shown,
        "notShown": hidden,
        "skippedTotal": len(skipped),
        "skippedReasons": tally(skipped, "reason"),
        "skippedWallTypes": tally(skipped, "wallType"),
        "next": "Show this to the user and, only after they confirm, call apply_wall_fire_rating with this "
                "previewId. Walls that already have a rating are left alone unless overwrite is true.",
    }


def tool_apply_wall_fire_rating(args):
    preview = _previews.get(args.get("previewId"))
    if preview is None or preview.get("kind") != "wallFire":
        raise ArchicadError("Unknown previewId. Run preview_wall_fire_rating first and let the user confirm it.")
    if not args.get("confirmedByUser"):
        raise ArchicadError("Not applied: the user has to confirm the preview first (confirmedByUser=true).")
    port = preview["port"]  # always the instance the preview was made on
    writes = []
    for change in preview["changes"]:
        if preview["valueType"] == "singleEnum":
            value = {"type": "singleEnum", "status": "normal",
                     "value": {"type": "displayValue", "displayValue": change["after"]}}
        else:
            value = {"type": "string", "status": "normal", "value": change["after"]}
        writes.append({"elementId": {"guid": change["wallGuid"]}, "propertyId": preview["propertyId"]["propertyId"],
                       "propertyValue": value})
    failed = []
    done = 0
    for part in chunks(writes):
        results = ac("API.SetPropertyValuesOfElements", {"elementPropertyValues": part}, port)["executionResults"]
        for change, result in zip(preview["changes"][done:done + len(part)], results):
            if not result.get("success"):
                failed.append({"wallId": change["wallId"], "wallGuid": change["wallGuid"],
                               "error": result.get("error", {}).get("message")})
        done += len(part)
    del _previews[args["previewId"]]
    # read back what is in the model now
    guids = [c["wallGuid"] for c in preview["changes"]]
    back = read_values([{"elementId": {"guid": g}} for g in guids], [fire_property(preview["which"])], port)
    now = {}
    for guid, row in zip(guids, back):
        now[guid] = plain(row[0])
    wrong = [c for c in preview["changes"] if now.get(c["wallGuid"]) != c["after"]]
    return {
        "port": port,
        "written": len(writes) - len(failed),
        "failedTotal": len(failed),
        "failedReasons": tally(failed, "error"),  # e.g. Teamwork: the walls are not reserved by this user
        "failed": failed[:DEFAULT_LIMIT],
        "readBackMismatch": len(wrong),
        "changes": [dict(c, now=now.get(c["wallGuid"])) for c in preview["changes"][:DEFAULT_LIMIT]],
        "undo": "'before' is kept in the preview rows; write it back with another preview (overwrite=true) if needed.",
    }


PROPERTY_ARG = {
    "type": "string", "default": "door",
    "description": "Which fire rating property. 'door' = built-in Window/Door > Fire Rating (free text). "
                   "'general' = GENERAL RATINGS > Fire Resistance Rating (fixed option list). Any other property: "
                   "'GROUP/Name' for a user-defined one, or a built-in non-localized name.",
}
PORT_ARG = {
    "type": "integer",
    "description": "Archicad API port, only needed when several Archicad instances are open. It is remembered.",
}
LIMIT_ARG = {
    "type": "integer", "default": DEFAULT_LIMIT,
    "description": "Maximum number of door rows returned. Counts and summaries always cover every door.",
}
ELEMENT_TYPE_ARG = {
    "type": "string", "enum": list(OPENING_TYPES), "default": "Door",
    "description": "'Door' (default) or 'Window'. Windows use the same fire rating properties and the same rules; "
                   "in the result the keys then say 'window' instead of 'door' (windowGuid, totalWindows...).",
}
DOOR_SCOPE_ARGS = {
    "excludeStoreys": {"type": "array", "items": {"type": "string"},
                       "description": "Whole storey names to leave out, e.g. storeys that only hold module or "
                                      "library sources."},
    "minStoreyElevation": {"type": "number",
                           "description": "Leave out doors whose home storey is below this elevation, in metres."},
}
GROUP_ARG = {
    "type": "string", "enum": list(GROUP_KEYS), "default": "layer",
    "description": "How to total the walls. 'wallType' = composite or profile name, or 'Basic <thickness> mm'. "
                   "'fireResistance' = the wall's fire resistance rating, e.g. to check which walls are rated.",
}
WALL_FILTER_ARGS = {
    "includeHiddenLayers": {"type": "boolean", "default": False,
                            "description": "Also measure walls on hidden layers. Ask the user first."},
    "excludeLayers": {"type": "array", "items": {"type": "string"},
                      "description": "Whole layer names to leave out, e.g. furniture or existing buildings."},
    "excludeRenovationStatus": {"type": "array", "items": {"type": "string"},
                                "description": "Renovation statuses to leave out, e.g. ['Demolished']."},
    "minHeight": {"type": "number", "description": "Leave out walls lower than this, in metres."},
    "excludeStoreys": {"type": "array", "items": {"type": "string"},
                       "description": "Whole storey names to leave out, e.g. storeys that only hold module or "
                                      "library sources."},
    "minStoreyElevation": {"type": "number",
                           "description": "Leave out walls whose home storey is below this elevation, in metres."},
}

TOOLS = [
    {
        "name": "archicad_status",
        "description": "Lists the running Archicad instances (port, version, number of doors, windows and walls) and tells "
                       "which one the other tools use.",
        "inputSchema": {"type": "object", "properties": {"port": PORT_ARG}},
        "handler": tool_status,
    },
    {
        "name": "find_doors_missing_fire_rating",
        "description": "Step 1 FIND. Lists every door whose fire rating is empty, with a count per storey. Doors "
                       "that cannot hold a rating (empty openings) are counted as notApplicable, not missing. "
                       "Pass elementType='Window' to check the windows instead. Read-only.",
        "inputSchema": {"type": "object", "properties": dict(DOOR_SCOPE_ARGS, **{
            "elementType": ELEMENT_TYPE_ARG, "property": PROPERTY_ARG, "port": PORT_ARG, "limit": LIMIT_ARG})},
        "handler": tool_find_missing,
    },
    {
        "name": "get_host_walls_of_doors",
        "description": "Step 2 CHECK. For each door returns its type, storey and the wall it sits in (wall ID, "
                       "thickness, wall fire resistance). Results marked 'ambiguous' or 'not found' need a manual "
                       "look. Pass elementType='Window' for the host walls of the windows. Read-only.",
        "inputSchema": {"type": "object", "properties": {
            "elementType": ELEMENT_TYPE_ARG,
            "doorGuids": {"type": "array", "items": {"type": "string"},
                          "description": "Limit to these doors. Leave out for all doors."},
            "windowGuids": {"type": "array", "items": {"type": "string"},
                            "description": "With elementType='Window': limit to these windows."},
            "port": PORT_ARG, "limit": LIMIT_ARG}},
        "handler": tool_host_walls,
    },
    {
        "name": "preview_fire_rating",
        "description": "Step 3 FIX, part 1. Works out which doors would get which rating from the given rules and "
                       "returns the table plus a previewId. Changes nothing in the model. The first matching rule "
                       "wins. Doors that already have a rating are left alone unless overwrite is true. Pass "
                       "elementType='Window' to rate windows; apply_fire_rating then writes to the windows.",
        "inputSchema": {"type": "object", "required": ["rules"], "properties": dict(DOOR_SCOPE_ARGS, **{
            "elementType": ELEMENT_TYPE_ARG,
            "property": PROPERTY_ARG,
            "includePerStorey": {"type": "boolean", "default": False,
                                 "description": "Also return the per-storey counts before the change (the same "
                                                "table find_doors_missing_fire_rating returns)."},
            "port": PORT_ARG,
            "limit": LIMIT_ARG,
            "overwrite": {"type": "boolean", "default": False},
            "rules": {"type": "array", "items": {"type": "object", "required": ["value"], "properties": {
                "value": {"type": "string", "description": "Rating to write, e.g. 'EI 60'."},
                "match": {"type": "object", "description": "All given conditions must hold. Empty = every door.",
                          "properties": {
                              "doorType": {"type": "string",
                                           "description": "Library part name, e.g. 'Double Door'. Must be the "
                                                          "whole name; a library version number at the end is "
                                                          "ignored ('Double Door 27' = 'Double Door')."},
                              "hostWallId": {"type": "string", "description": "Element ID of the host wall."},
                              "storey": {"type": "string",
                                         "description": "Storey name as returned by the other tools, e.g. "
                                                        "'1. 1st Floor', or its elevation like '+3.50 m'."},
                              "minWidth": {"type": "number", "description": "Door width in metres, at least."},
                              "doorGuids": {"type": "array", "items": {"type": "string"}},
                              "windowType": {"type": "string",
                                             "description": "With elementType='Window': library part name of "
                                                            "the window, same matching as doorType."},
                              "windowGuids": {"type": "array", "items": {"type": "string"},
                                              "description": "With elementType='Window'."}}}}}}})},
        "handler": tool_preview,
    },
    {
        "name": "apply_fire_rating",
        "description": "Step 3 FIX, part 2. Writes the previewed ratings (doors or windows, as previewed) to the "
                       "model in one batch, reads them back and returns the per-storey counts afterwards. Call it only after the user has seen the preview and agreed. "
                       "It always writes to the Archicad instance the preview was made on.",
        "inputSchema": {"type": "object", "required": ["previewId", "confirmedByUser"], "properties": {
            "previewId": {"type": "string"},
            "confirmedByUser": {"type": "boolean", "description": "True only if the user approved the preview."}}},
        "handler": tool_apply,
    },
    {
        "name": "preview_wall_fire_rating",
        "description": "Wall fire rating, part 1. Works out which WALLS would get which rating from the given rules "
                       "and returns the table plus a previewId. Changes nothing in the model. The first matching "
                       "rule wins. Walls that already have a rating are left alone unless overwrite is true. The "
                       "value must be in the property's option list (default property: GENERAL RATINGS > Fire "
                       "Resistance Rating); otherwise the error lists the allowed values.",
        "inputSchema": {"type": "object", "required": ["rules"], "properties": dict(WALL_FILTER_ARGS, **{
            "property": dict(PROPERTY_ARG, default="general"),
            "overwrite": {"type": "boolean", "default": False},
            "limit": LIMIT_ARG, "port": PORT_ARG,
            "rules": {"type": "array", "items": {"type": "object", "required": ["value"], "properties": {
                "value": {"type": "string", "description": "Rating to write, e.g. 'EI 60'."},
                "match": {"type": "object", "description": "All given conditions must hold. Empty = every wall.",
                          "properties": {
                              "hasDoor": {"type": "boolean",
                                          "description": "true = only walls that host a door; false = only walls "
                                                         "without a door."},
                              "layer": {"type": "string", "description": "Whole layer name."},
                              "layerContains": {"type": "string", "description": "Part of the layer name."},
                              "wallType": {"type": "string", "description": "Whole wall type name, e.g. "
                                                                            "'Basic 150 mm'."},
                              "wallTypeContains": {"type": "string"},
                              "minThickness": {"type": "number", "description": "Wall thickness in mm, at least."},
                              "maxThickness": {"type": "number", "description": "Wall thickness in mm, at most."},
                              "wallId": {"type": "string", "description": "Element ID of the wall."},
                              "storey": {"type": "string", "description": "Storey name, e.g. '1. 1st Floor', or "
                                                                          "its elevation like '+3.50 m'."},
                              "wallGuids": {"type": "array", "items": {"type": "string"}}}}}}}})},
        "handler": tool_preview_wall_fire_rating,
    },
    {
        "name": "apply_wall_fire_rating",
        "description": "Wall fire rating, part 2. Writes the previewed ratings to the walls in one batch and reads "
                       "them back. Call it only after the user has seen the preview and agreed. It always writes to "
                       "the Archicad instance the preview was made on.",
        "inputSchema": {"type": "object", "required": ["previewId", "confirmedByUser"], "properties": {
            "previewId": {"type": "string"},
            "confirmedByUser": {"type": "boolean", "description": "True only if the user approved the preview."}}},
        "handler": tool_apply_wall_fire_rating,
    },
    {
        "name": "get_wall_quantities",
        "description": "Part 2, steps ASK and CONFIRM. Measures every wall and totals length and area per layer, "
                       "wall type or fire resistance, with the height range of each group, a count of walls per "
                       "fire resistance rating and what was left out (hidden layers, excluded layers). Use it to map "
                       "layers to rates, to agree heights and exclusions with the user before pricing, and to check "
                       "the fire resistance of every wall (listWalls=true gives it per wall). Read-only.",
        "inputSchema": {"type": "object", "properties": dict(WALL_FILTER_ARGS, **{
            "groupBy": GROUP_ARG,
            "listWalls": {"type": "boolean", "default": False,
                          "description": "Also return one row per wall (up to limit)."},
            "limit": LIMIT_ARG, "port": PORT_ARG})},
        "handler": tool_wall_quantities,
    },
    {
        "name": "price_walls",
        "description": "Part 2, step PRICE. Prices the walls with the user's rates per m2 and returns the cost "
                       "table: length, area and low, mid and high cost per group, plus totals, the walls no rate "
                       "matched and the assumptions used. Call it after the user confirmed rates, heights and "
                       "exclusions. Read-only.",
        "inputSchema": {"type": "object", "required": ["rates"], "properties": dict(WALL_FILTER_ARGS, **{
            "rates": {"type": "array", "description": "The first matching rate wins, so put specific rates first.",
                      "items": {"type": "object", "required": ["mid"], "properties": {
                          "layer": {"type": "string", "description": "Whole layer name as returned by "
                                                                     "get_wall_quantities. Leave out for any layer."},
                          "wallType": {"type": "string", "description": "Whole wall type name, e.g. 'Basic 150 mm'. "
                                                                        "Leave out for any type."},
                          "wallTypeContains": {"type": "string",
                                               "description": "Part of the wall type name, e.g. 'Drywall'."},
                          "layerContains": {"type": "string", "description": "Part of the layer name."},
                          "minThickness": {"type": "number", "description": "Wall thickness in mm, at least."},
                          "maxThickness": {"type": "number", "description": "Wall thickness in mm, at most."},
                          "label": {"type": "string",
                                    "description": "Name of this rate, e.g. 'Drywall'. Shown in the cost table "
                                                   "and usable as groupBy 'rate'."},
                          "low": {"type": "number", "description": "Low price per m2. Defaults to mid."},
                          "mid": {"type": "number", "description": "Mid price per m2."},
                          "high": {"type": "number", "description": "High price per m2. Defaults to mid."},
                          "height": {"type": "number",
                                     "description": "Agreed wall height in metres to use instead of the modelled "
                                                    "height. Only used with areaBasis 'lengthXheight'."}}}},
            "areaBasis": {"type": "string", "enum": list(AREA_BASES), "default": "lengthXheight",
                          "description": "'lengthXheight' = length x height, openings not deducted. 'gross' / "
                                         "'net' = face area from Archicad without / with openings deducted."},
            "lengthBasis": {"type": "string", "enum": list(LENGTH_BASES), "default": "reference",
                            "description": "'reference' = reference line length, 'center' = centre length."},
            "groupBy": dict(GROUP_ARG, enum=list(GROUP_KEYS) + ["rate"],
                            description=GROUP_ARG["description"] + " 'rate' = one row per rate."),
            "currency": {"type": "string", "default": "USD", "description": "Label only, no conversion."},
            "port": PORT_ARG})},
        "handler": tool_price_walls,
    },
    {
        "name": "preview_rename_elements",
        "description": "Rename, part 1. Works out the new Element IDs for the given doors, windows or walls and "
                       "returns the before/after table plus a previewId. Changes nothing in the model. Also lists "
                       "the Element IDs that several elements share now and after the change; a rename that would "
                       "create a shared ID is refused unless allowDuplicates is true.",
        "inputSchema": {"type": "object", "required": ["renames"], "properties": {
            "elementType": {"type": "string", "enum": list(RENAME_TYPES), "default": "Door"},
            "renames": {"type": "array", "items": {"type": "object", "required": ["guid", "newId"], "properties": {
                "guid": {"type": "string", "description": "Element guid as returned by the other tools."},
                "newId": {"type": "string", "description": "New Element ID, e.g. 'D - 23'."}}}},
            "allowDuplicates": {"type": "boolean", "default": False,
                                "description": "Allow a new ID that another element of this type also has."},
            "port": PORT_ARG}},
        "handler": tool_preview_rename,
    },
    {
        "name": "apply_rename_elements",
        "description": "Rename, part 2. Writes the previewed Element IDs to the model in one batch and reads them "
                       "back. Call it only after the user has seen the preview and agreed. It refuses when an "
                       "element changed in Archicad since the preview.",
        "inputSchema": {"type": "object", "required": ["previewId", "confirmedByUser"], "properties": {
            "previewId": {"type": "string"},
            "confirmedByUser": {"type": "boolean", "description": "True only if the user approved the preview."}}},
        "handler": tool_apply_rename,
    },
]


# ---------------------------------------------------------------- MCP over stdio

def handle(message):
    method = message.get("method")
    params = message.get("params") or {}
    if method == "initialize":
        return {
            "protocolVersion": params.get("protocolVersion", "2024-11-05"),
            "capabilities": {"tools": {}},
            "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
        }
    if method == "ping":
        return {}
    if method == "tools/list":
        return {"tools": [{k: v for k, v in tool.items() if k != "handler"} for tool in TOOLS]}
    if method == "tools/call":
        tool = next((t for t in TOOLS if t["name"] == params.get("name")), None)
        if tool is None:
            raise LookupError("Unknown tool: %s" % params.get("name"))
        try:
            result = tool["handler"](params.get("arguments") or {})
            return {"content": [{"type": "text", "text": json.dumps(result, ensure_ascii=False, indent=1)}]}
        except ArchicadError as error:
            return {"content": [{"type": "text", "text": str(error)}], "isError": True}
    raise LookupError("Method not found: %s" % method)


def main():
    sys.stdin.reconfigure(encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8", newline="\n")
    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
        except ValueError:
            continue
        if "id" not in message:  # notification, nothing to answer
            continue
        reply = {"jsonrpc": "2.0", "id": message["id"]}
        try:
            reply["result"] = handle(message)
        except LookupError as error:
            reply["error"] = {"code": -32601, "message": str(error)}
        except Exception as error:  # keep the server alive on unexpected failures
            reply["error"] = {"code": -32603, "message": "%s: %s" % (type(error).__name__, error)}
        sys.stdout.write(json.dumps(reply, ensure_ascii=False) + "\n")
        sys.stdout.flush()


if __name__ == "__main__":
    main()
