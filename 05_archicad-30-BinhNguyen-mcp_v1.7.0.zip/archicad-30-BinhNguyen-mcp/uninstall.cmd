@echo off
rem Double-click to remove the Archicad MCP server and its Claude registrations.
call "%~dp0install.cmd" --uninstall
