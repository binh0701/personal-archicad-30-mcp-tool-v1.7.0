#!/usr/bin/env python3
"""Installs the archicad-30-BinhNguyen MCP server on this computer.

  python install.py              install / update, register in Claude Code and Claude Desktop
  python install.py --uninstall  remove the files and both registrations

Standard library only. Config files are backed up before they are changed.
"""
import json
import os
import shutil
import subprocess
import sys
import time

NAME = "archicad-30-BinhNguyen"
HERE = os.path.dirname(os.path.abspath(__file__))
TARGET_DIR = os.path.join(os.environ.get("LOCALAPPDATA") or os.path.expanduser("~"), NAME)
TARGET = os.path.join(TARGET_DIR, "server.py")
DESKTOP_CONFIG = os.path.join(os.environ.get("APPDATA") or os.path.expanduser("~"), "Claude",
                              "claude_desktop_config.json")


def say(text):
    print(text, flush=True)


def claude_cli():
    return shutil.which("claude") or shutil.which("claude.cmd") or shutil.which("claude.exe")


def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")


# ------------------------------------------------------------------ Claude Code
def register_claude_code(python):
    cli = claude_cli()
    if not cli:
        say("  Claude Code CLI not found on PATH. Register it yourself later with:\n"
            '    claude mcp add --scope user %s -- "%s" "%s"' % (NAME, python, TARGET))
        return False
    run([cli, "mcp", "remove", NAME, "--scope", "user"])  # ignore 'not found'
    result = run([cli, "mcp", "add", "--scope", "user", NAME, "--", python, TARGET])
    if result.returncode != 0:
        say("  Claude Code registration FAILED:\n" + (result.stderr or result.stdout))
        return False
    say("  Claude Code: registered (user scope, works in every project).")
    return True


def unregister_claude_code():
    cli = claude_cli()
    if cli:
        result = run([cli, "mcp", "remove", NAME, "--scope", "user"])
        say("  Claude Code: %s" % ("removed" if result.returncode == 0 else "was not registered"))


# ------------------------------------------------------------------ Claude Desktop
def load_desktop_config():
    if not os.path.exists(DESKTOP_CONFIG):
        return {}
    with open(DESKTOP_CONFIG, encoding="utf-8-sig") as handle:
        text = handle.read().strip()
    return json.loads(text) if text else {}


def save_desktop_config(config):
    if os.path.exists(DESKTOP_CONFIG):
        stamp, n = DESKTOP_CONFIG + ".bak-" + time.strftime("%Y%m%d-%H%M%S"), 1
        backup = stamp
        while os.path.exists(backup):  # never overwrite an earlier backup
            n += 1
            backup = "%s-%d" % (stamp, n)
        shutil.copy2(DESKTOP_CONFIG, backup)
        say("  Backup of Claude Desktop config: " + backup)
    os.makedirs(os.path.dirname(DESKTOP_CONFIG), exist_ok=True)
    with open(DESKTOP_CONFIG, "w", encoding="utf-8") as handle:
        json.dump(config, handle, indent=2, ensure_ascii=False)


def register_claude_desktop(python):
    if not os.path.isdir(os.path.dirname(DESKTOP_CONFIG)):
        say("  Claude Desktop not found (no %s). Skipped." % os.path.dirname(DESKTOP_CONFIG))
        return False
    try:
        config = load_desktop_config()
    except ValueError as error:
        say("  Claude Desktop config is not valid JSON, left untouched: %s" % error)
        return False
    config.setdefault("mcpServers", {})[NAME] = {"command": python, "args": [TARGET]}
    save_desktop_config(config)
    say("  Claude Desktop: registered. Quit and reopen Claude Desktop to load it.")
    return True


def unregister_claude_desktop():
    try:
        config = load_desktop_config()
    except ValueError:
        return
    if NAME in config.get("mcpServers", {}):
        del config["mcpServers"][NAME]
        save_desktop_config(config)
        say("  Claude Desktop: removed")


# ------------------------------------------------------------------ self-test
def self_test(python):
    """Starts the installed server, lists its tools and asks it for the running Archicad instances."""
    requests = [
        {"jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {"protocolVersion": "2024-11-05"}},
        {"jsonrpc": "2.0", "id": 2, "method": "tools/list"},
        {"jsonrpc": "2.0", "id": 3, "method": "tools/call", "params": {"name": "archicad_status", "arguments": {}}},
    ]
    stdin = "".join(json.dumps(r) + "\n" for r in requests)
    try:
        result = subprocess.run([python, TARGET], input=stdin, capture_output=True, text=True,
                                encoding="utf-8", timeout=60)
    except subprocess.TimeoutExpired:
        say("  Self-test: server did not answer within 60 s.")
        return False
    replies = {}
    for line in result.stdout.splitlines():
        try:
            reply = json.loads(line)
            replies[reply.get("id")] = reply
        except ValueError:
            pass
    if 1 not in replies or 2 not in replies:
        say("  Self-test FAILED. Server output:\n" + result.stdout + result.stderr)
        return False
    info = replies[1]["result"]["serverInfo"]
    tools = [t["name"] for t in replies[2]["result"]["tools"]]
    say("  Self-test: %s %s starts and offers %d tools." % (info["name"], info["version"], len(tools)))
    status = replies.get(3, {}).get("result", {})
    text = (status.get("content") or [{}])[0].get("text", "")
    if status.get("isError") or not text:
        say("  Archicad: not reachable now (%s). Open a model in Archicad 30 and ask Claude to run "
            "archicad_status." % (text.strip() or "no answer"))
    else:
        data = json.loads(text)
        for inst in data.get("instances", []):
            say("  Archicad found: version %s on port %s, %s doors, %s walls."
                % (inst["archicad"]["version"], inst["port"], inst.get("doors"), inst.get("walls")))
    return True


# ------------------------------------------------------------------ main
def install():
    if sys.version_info < (3, 8):
        sys.exit("Python 3.8 or newer is needed, this is %s." % sys.version.split()[0])
    python = sys.executable
    source = os.path.join(HERE, "server.py")
    if not os.path.exists(source):
        sys.exit("server.py is missing next to install.py.")
    say("Installing %s" % NAME)
    say("  Python: %s (%s)" % (python, sys.version.split()[0]))
    os.makedirs(TARGET_DIR, exist_ok=True)
    if os.path.exists(TARGET):
        shutil.copy2(TARGET, TARGET + ".previous")
    shutil.copy2(source, TARGET)
    say("  Server copied to: " + TARGET)
    register_claude_code(python)
    register_claude_desktop(python)
    self_test(python)
    say("\nDone. Restart Claude Code / Claude Desktop, then ask: \"Use the Archicad MCP: archicad_status\".")


def uninstall():
    say("Removing %s" % NAME)
    unregister_claude_code()
    unregister_claude_desktop()
    if os.path.isdir(TARGET_DIR):
        shutil.rmtree(TARGET_DIR)
        say("  Files removed: " + TARGET_DIR)
    say("Done.")


if __name__ == "__main__":
    uninstall() if "--uninstall" in sys.argv else install()
