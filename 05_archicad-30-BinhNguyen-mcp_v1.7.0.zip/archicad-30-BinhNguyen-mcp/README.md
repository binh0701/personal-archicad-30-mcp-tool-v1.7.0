# archicad-30-BinhNguyen — Archicad MCP server

This MCP server lets Claude work on the model that is open in Archicad 30. It covers both parts of the AI Productivity Challenge:

- **Part 1:** find doors with a missing fire rating, then fill them in one batch. Since v1.7.0 the same tools also work on windows.
- **Part 2:** measure every wall and price it.

## Requirements
- Windows with **Archicad 30** (built for AC30; AC29 also worked in testing). The model must be open in Archicad. The Archicad JSON API listens on ports 19723–19743 and is on by default.
- **Python 3.8+** from python.org. During setup, tick *Add python.exe to PATH*. No extra packages and no Archicad add-on are needed.
- **Claude Code** and/or **Claude Desktop**.

## Install (about 1 minute)
1. Unzip the folder anywhere.
2. Double-click **`install.cmd`**. It does five things:
   - copies `server.py` to `%LOCALAPPDATA%\archicad-30-BinhNguyen\`
   - registers the server in **Claude Code** at user scope, so it works in every project (`claude mcp add`)
   - registers the server in **Claude Desktop** (`%APPDATA%\Claude\claude_desktop_config.json`), after backing that file up
   - starts the server once as a self-test
   - reports whether Archicad was found
3. Restart Claude Code / Claude Desktop.
4. Ask Claude: *"Use the Archicad MCP: archicad_status"*. It should list your Archicad instance and its door and wall counts.

To update, run `install.cmd` again; the previous `server.py` is kept as `server.py.previous`. To remove everything, run **`uninstall.cmd`**.

If the `claude` command is not on PATH, register the server by hand:
```
claude mcp add --scope user archicad-30-BinhNguyen -- "<path to python.exe>" "%LOCALAPPDATA%\archicad-30-BinhNguyen\server.py"
```

## Tools
| Tool | What it does | Changes the model? |
|---|---|---|
| `archicad_status` | Lists running Archicad instances (version, port, number of doors, windows and walls) | no |
| `find_doors_missing_fire_rating` | Part 1 FIND: doors with an empty fire rating, counted per storey | no |
| `get_host_walls_of_doors` | Part 1 CHECK: the host wall of each door (ID, thickness, fire resistance) | no |
| `preview_fire_rating` / `apply_fire_rating` | Part 1 FIX: preview the ratings, then write them in one batch after you confirm | yes, after confirmation |
| `get_wall_quantities` | Part 2: length, area, heights and fire rating per layer or wall type; hidden layers listed separately | no |
| `price_walls` | Part 2: low / mid / high cost table from your rates per m² | no |
| `preview_wall_fire_rating` / `apply_wall_fire_rating` | Fire resistance of walls, preview, then confirm | yes, after confirmation |
| `preview_rename_elements` / `apply_rename_elements` | Change the Element ID of doors, windows or walls, preview, then confirm | yes, after confirmation |

**Windows (v1.7.0):** the four Part 1 tools (`find_doors_missing_fire_rating`, `get_host_walls_of_doors`, `preview_fire_rating`, `apply_fire_rating`) take `elementType: "Window"`. They then work on the windows with the same properties and rules, and the result keys say `window` instead of `door` (`windowGuid`, `totalWindows`, rule keys `windowType` / `windowGuids`). Without `elementType` they work on doors exactly as before.

Ground rules built in: the server only writes values of **existing** properties (fire rating, Element ID). It never creates, moves or deletes elements. Every write needs a preview that you confirm first. The Part 2 tools are read-only.

## Troubleshooting
- **"No Archicad instance found"**: open a project in Archicad 30 and wait until it has finished loading.
- **Several Archicad windows open**: pass `port` once, e.g. 19724. The server remembers it.
- **Teamwork project**: reserve the elements before writing, otherwise Archicad answers "permission denied".
- **Tools do not appear in Claude**: restart Claude. In Claude Code, check the server with `claude mcp list`.
